import ctypes

# Устанавливаем заголовок окна
ctypes.windll.kernel32.SetConsoleTitleW("сравнение чисел.exe / comparing numbers.exe")

while True:
    a = int(input("Введите число: "))
    b = int(input("Введите ещё одно число: "))
    cde=a-b
    edc=b-a
    if a > b:
        print("первое число меньше второго на", cde, ". если не хотите продолжать, закройте программу.")
    elif a < b:
        print("второе число больше первого на", edc, ". если не хотите продолжать, закройте программу.")
    else:
        print("вы не то ввели")
